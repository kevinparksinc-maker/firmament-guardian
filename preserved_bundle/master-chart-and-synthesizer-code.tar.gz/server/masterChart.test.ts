import { describe, it, expect } from "vitest";
import { buildUnifiedMasterChart, getLayer, getEvidence, getModeView } from "./masterChart";

const SAMPLE_INPUT = {
  location: "Alexandria, Egypt",
  latitude: 31.2001,
  longitude: 29.9187,
  timezone: "Africa/Cairo",
  date: "1988-08-08",
  time: "12:00",
  mode: "natal" as const,
};

describe("Unified Master Chart Architecture", () => {
  it("builds an immutable UnifiedMasterChartSnapshot with complete validation", async () => {
    const snapshot = await buildUnifiedMasterChart(SAMPLE_INPUT);

    expect(snapshot).toBeDefined();
    expect(snapshot.snapshotId).toMatch(/^umc-[a-f0-9]{16}$/);
    expect(snapshot.schemaVersion).toBe("1.0.0");
    expect(snapshot.validation.complete).toBe(true);
    expect(snapshot.validation.errors).toHaveLength(0);
    expect(snapshot.validation.totalMethods).toBe(16);
    expect(snapshot.validation.computedWithResultCount).toBeGreaterThanOrEqual(10);
  });

  it("produces identical snapshot IDs for identical inputs (deterministic stability)", async () => {
    const snap1 = await buildUnifiedMasterChart(SAMPLE_INPUT);
    const snap2 = await buildUnifiedMasterChart(SAMPLE_INPUT);

    expect(snap1.snapshotId).toBe(snap2.snapshotId);
  });

  it("produces distinct snapshot IDs when date or location changes", async () => {
    const snap1 = await buildUnifiedMasterChart(SAMPLE_INPUT);
    const snap2 = await buildUnifiedMasterChart({
      ...SAMPLE_INPUT,
      date: "1992-04-15",
    });

    expect(snap1.snapshotId).not.toBe(snap2.snapshotId);
  });

  it("preserves distinct God View and Agent View projections from the same celestial state", async () => {
    const snapshot = await buildUnifiedMasterChart(SAMPLE_INPUT);

    expect(snapshot.godView.cosmicFrame).toBe("fixed-aries-1-to-pisces-12");
    expect(snapshot.godView.polarisCenter).toBe(true);
    expect(snapshot.godView.placements.length).toBeGreaterThanOrEqual(7);

    expect(snapshot.agentView.houseSystem).toBe("equal-house-from-ascendant");
    expect(snapshot.agentView.ascendantAnchor).toBeDefined();
    expect(snapshot.agentView.placements.length).toBeGreaterThanOrEqual(7);

    const modeView = getModeView(snapshot, "god");
    expect(modeView).toEqual(snapshot.godView);
  });

  it("registers all 16 canonical method layers with truthful execution statuses", async () => {
    const snapshot = await buildUnifiedMasterChart(SAMPLE_INPUT);

    const expectedLayers = [
      "western-planets-and-signs",
      "western-houses-and-angles",
      "western-aspects-and-orbs",
      "western-essential-dignities",
      "fixed-stars-royal-watchers",
      "arabic-hermetic-lots",
      "arabic-lunar-manazil",
      "vedic-nakshatras-and-padas",
      "vedic-vargas-divisional",
      "vedic-dasha-and-ashtakavarga",
      "vedic-graha-drishti",
      "chinese-lunar-mansions-xiu",
      "elemental-decans",
      "kabbalah-sefer-yetzirah",
      "genesis-behavioral-patterns",
      "transit-activation-layer",
    ];

    for (const layerId of expectedLayers) {
      const layer = getLayer(snapshot, layerId);
      expect(layer, `Missing layer: ${layerId}`).toBeDefined();
      expect(layer!.id).toBe(layerId);
      expect(layer!.status).toBeDefined();
    }

    // Chinese 28 Xiu must have explicit reference-only status
    const chineseLayer = getLayer(snapshot, "chinese-lunar-mansions-xiu");
    expect(chineseLayer?.status).toBe("reference-only");
    expect(chineseLayer?.notes).toContain("Historical determinative equatorial star catalog preserved as reference");

    // Arabic Hermetic Lots must have computed results
    const lotsLayer = getLayer(snapshot, "arabic-hermetic-lots");
    expect(lotsLayer?.status).toBe("computed-with-result");
    expect((lotsLayer?.results as any[]).length).toBeGreaterThan(0);

    // Vedic Nakshatras must be computed
    const nakLayer = getLayer(snapshot, "vedic-nakshatras-and-padas");
    expect(nakLayer?.status).toBe("computed-with-result");
  });

  it("correctly resolves evidence IDs via getEvidence selector", async () => {
    const snapshot = await buildUnifiedMasterChart(SAMPLE_INPUT);

    const found = getEvidence(snapshot, "planet-sun");
    expect(found).toBeDefined();
    expect(found?.id).toBe("western-planets-and-signs");
  });

  it("activates transit activation layer when mode is transit or combined", async () => {
    const snapshot = await buildUnifiedMasterChart({
      ...SAMPLE_INPUT,
      mode: "combined",
      transitDate: "2026-10-31",
      transitTime: "12:00",
    });

    const transitLayer = getLayer(snapshot, "transit-activation-layer");
    expect(transitLayer).toBeDefined();
    expect(transitLayer?.frame).toBe("transit");
    expect(transitLayer?.status).toBe("computed-with-result");
    expect(snapshot.transit).toBeDefined();
  });
});
